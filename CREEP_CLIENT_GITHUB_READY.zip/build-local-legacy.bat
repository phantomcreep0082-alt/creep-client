@echo off
setlocal EnableExtensions
 title CREEP CLIENT - Windows Build
REM Resolve the script folder without a trailing backslash. A trailing backslash
REM immediately before a closing quote can escape that quote in Windows argv parsing.
for %%I in ("%~dp0.") do set "ROOT=%%~fI"
cd /d "%ROOT%"
set "PATH=%PATH%;%LOCALAPPDATA%\Microsoft\WinGet\Links"
set "TOOLS=%ROOT%tools"
set "QT_ROOT=%TOOLS%\Qt\6.8.3\msvc2022_64"
set "CREEP_VCPKG_ROOT=%ROOT%cmake\vcpkg"
set "BUILD_DIR=%ROOT%build"
set "INSTALL_DIR=%ROOT%dist"
set "RELEASE_DIR=%ROOT%release"
set "INNO_SCRIPT=%ROOT%installer\CREEP_CLIENT.iss"

echo.
echo  ============================================
echo          C R E E P   C L I E N T
echo           Native Windows Builder
echo  ============================================
echo.

where winget >nul 2>nul
if errorlevel 1 (
  echo [ERROR] winget is required to install the Windows build tools.
  echo Install or update App Installer from Microsoft Store, then run build.bat again.
  pause
  exit /b 1
)

where git >nul 2>nul
if errorlevel 1 (
  echo [SETUP] Installing Git...
  winget install --id Git.Git --exact --source winget --accept-package-agreements --accept-source-agreements
  if errorlevel 1 goto :install_error
  set "PATH=%PATH%;C:\Program Files\Git\cmd"
)

where cmake >nul 2>nul
if errorlevel 1 (
  echo [SETUP] Installing CMake...
  winget install --id Kitware.CMake --exact --source winget --accept-package-agreements --accept-source-agreements
  if errorlevel 1 goto :install_error
  set "PATH=%PATH%;C:\Program Files\CMake\bin"
)

where py >nul 2>nul
if errorlevel 1 (
  echo [SETUP] Installing Python...
  winget install --id Python.Python.3.12 --exact --source winget --accept-package-agreements --accept-source-agreements
  if errorlevel 1 goto :install_error
  set "PATH=%PATH%;%LocalAppData%\Programs\Python\Python312;%LocalAppData%\Programs\Python\Python312\Scripts"
)

for /d %%J in ("C:\Program Files\Eclipse Adoptium\jdk-17*") do set "JAVA_HOME=%%~fJ"
if not defined JAVA_HOME (
  echo [SETUP] Installing Temurin JDK 17 for the launcher build tools...
  winget install --id EclipseAdoptium.Temurin.17.JDK --exact --source winget --accept-package-agreements --accept-source-agreements
  if errorlevel 1 goto :install_error
  for /d %%J in ("C:\Program Files\Eclipse Adoptium\jdk-17*") do set "JAVA_HOME=%%~fJ"
)
if defined JAVA_HOME set "PATH=%JAVA_HOME%\bin;%PATH%"
where java >nul 2>nul
if errorlevel 1 (
  echo [ERROR] Java 17 was not found after installation.
  pause
  exit /b 1
)

if not exist "%TOOLS%" mkdir "%TOOLS%"
REM Check the actual Qt components used by this build, not only qmake.exe.
if not exist "%QT_ROOT%\bin\qmake.exe" goto :install_qt
if not exist "%QT_ROOT%\lib\cmake\Qt6NetworkAuth\Qt6NetworkAuthConfig.cmake" goto :install_qt
if not exist "%QT_ROOT%\lib\cmake\Qt6Svg\Qt6SvgConfig.cmake" goto :install_qt
goto :qt_ready

:install_qt
echo [SETUP] Installing Qt 6.8.3 and required components. This is a large download...
py -m pip install --user --upgrade aqtinstall
if errorlevel 1 goto :install_error
REM qtsvg is an archive in this Qt repository, not an aqt module.
py -m aqt install-qt windows desktop 6.8.3 win64_msvc2022_64 --outputdir "%TOOLS%\Qt" -m qtimageformats qtnetworkauth --archives qtsvg
if errorlevel 1 goto :install_error
if not exist "%QT_ROOT%\lib\cmake\Qt6NetworkAuth\Qt6NetworkAuthConfig.cmake" (
  echo [ERROR] Qt NetworkAuth was not installed correctly.
  goto :install_error
)
if not exist "%QT_ROOT%\lib\cmake\Qt6Svg\Qt6SvgConfig.cmake" (
  echo [ERROR] Qt SVG archive was not installed correctly.
  goto :install_error
)
:qt_ready

if not exist "%CREEP_VCPKG_ROOT%\bootstrap-vcpkg.bat" (
  echo [SETUP] Downloading vcpkg dependency manager...
  if exist "%CREEP_VCPKG_ROOT%" rmdir /s /q "%CREEP_VCPKG_ROOT%"
  git clone https://github.com/microsoft/vcpkg.git "%CREEP_VCPKG_ROOT%"
  if errorlevel 1 goto :install_error
)
if not exist "%CREEP_VCPKG_ROOT%\vcpkg.exe" (
  echo [SETUP] Bootstrapping vcpkg...
  call "%CREEP_VCPKG_ROOT%\bootstrap-vcpkg.bat" -disableMetrics
  if errorlevel 1 goto :install_error
)

if not exist "%ROOT%libraries\libnbtplusplus\CMakeLists.txt" (
  echo [SETUP] Downloading required Minecraft NBT library...
  if exist "%ROOT%libraries\libnbtplusplus" rmdir /s /q "%ROOT%libraries\libnbtplusplus"
  git clone --depth 1 https://github.com/PrismLauncher/libnbtplusplus.git "%ROOT%libraries\libnbtplusplus"
  if errorlevel 1 goto :install_error
)

set "VSWHERE=%ProgramFiles(x86)%\Microsoft Visual Studio\Installer\vswhere.exe"
if not exist "%VSWHERE%" (
  echo [SETUP] Installing Microsoft C++ Build Tools...
  winget install --id Microsoft.VisualStudio.2022.BuildTools --exact --source winget --override "--wait --quiet --add Microsoft.VisualStudio.Workload.VCTools --includeRecommended" --accept-package-agreements --accept-source-agreements
  if errorlevel 1 goto :install_error
)
if not exist "%VSWHERE%" (
  echo [ERROR] Visual Studio Build Tools installer was not found.
  echo Install Visual Studio 2022 Build Tools with the C++ workload and rerun this file.
  pause
  exit /b 1
)
for /f "usebackq tokens=*" %%i in (`"%VSWHERE%" -latest -products * -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -property installationPath`) do set "VSINSTALL=%%i"
if not defined VSINSTALL (
  echo [ERROR] MSVC C++ compiler is missing. Install the Visual C++ build tools workload.
  pause
  exit /b 1
)
if not exist "%VSINSTALL%\Common7\Tools\VsDevCmd.bat" (
  echo [ERROR] Could not locate VsDevCmd.bat.
  pause
  exit /b 1
)
call "%VSINSTALL%\Common7\Tools\VsDevCmd.bat" -arch=x64 -host_arch=x64
if errorlevel 1 goto :install_error

where ninja >nul 2>nul
if errorlevel 1 (
  echo [SETUP] Installing Ninja...
  winget install --id Ninja-build.Ninja --exact --source winget --accept-package-agreements --accept-source-agreements
  if errorlevel 1 goto :install_error
  set "PATH=%PATH%;C:\Program Files\Ninja"
)
where ninja >nul 2>nul
if errorlevel 1 (
  echo [ERROR] Ninja was not found. Reopen a terminal after installing Ninja and retry.
  pause
  exit /b 1
)

set "MSA_CLIENT_ID="
echo.
echo Microsoft sign-in requires a client ID from your own Microsoft app registration.
echo Leave it blank to build the launcher without Microsoft account sign-in enabled.
set /p "MSA_CLIENT_ID=Microsoft application client ID (Enter to skip): "

if not exist "%BUILD_DIR%" mkdir "%BUILD_DIR%"
if exist "%INSTALL_DIR%" rmdir /s /q "%INSTALL_DIR%"

echo.
echo [1/4] Configuring CREEP CLIENT...
echo Using bundled vcpkg: %CREEP_VCPKG_ROOT%
REM Resolve the real cmake.exe explicitly. Some Visual Studio developer prompts expose
REM wrappers/shims that can collapse a multi-line batch invocation into one argument.
set "CMAKE_EXE="
for /f "delims=" %%C in ('where cmake.exe 2^>nul') do if not defined CMAKE_EXE set "CMAKE_EXE=%%C"
if not defined CMAKE_EXE (
  echo [ERROR] cmake.exe was not found on PATH. Install CMake and rerun build.bat.
  goto :install_error
)
echo Using CMake: %CMAKE_EXE%
REM Keep this invocation on one physical line to avoid CMD caret/quoting corruption.
"%CMAKE_EXE%" -S "%ROOT%" -B "%BUILD_DIR%" -G Ninja -DCMAKE_BUILD_TYPE=Release "-DCMAKE_INSTALL_PREFIX=%INSTALL_DIR%" "-DCMAKE_PREFIX_PATH=%QT_ROOT%" "-DCMAKE_TOOLCHAIN_FILE=%CREEP_VCPKG_ROOT%\scripts\buildsystems\vcpkg.cmake" -DVCPKG_TARGET_TRIPLET=x64-windows "-DLauncher_MSA_CLIENT_ID=%MSA_CLIENT_ID%" "-DLauncher_CURSEFORGE_API_KEY=" "-DLauncher_IMGUR_CLIENT_ID=" "-DLauncher_BUILD_PLATFORM=creepclient" -DLauncher_ENABLE_JAVA_DOWNLOADER=ON -DENABLE_LTO=OFF -DBUILD_TESTING=OFF
if errorlevel 1 goto :build_error

echo.
echo [2/4] Compiling CREEP CLIENT. First build can take a long time...
cmake --build "%BUILD_DIR%" --parallel 2
if errorlevel 1 goto :build_error

echo.
echo [3/4] Packaging application and Qt runtime...
cmake --install "%BUILD_DIR%" --config Release --prefix "%INSTALL_DIR%"
if errorlevel 1 goto :build_error
cmake --install "%BUILD_DIR%" --config Release --prefix "%INSTALL_DIR%" --component bundle
if errorlevel 1 goto :build_error
cmake --install "%BUILD_DIR%" --config Release --prefix "%INSTALL_DIR%" --component portable
if errorlevel 1 goto :build_error

echo.
echo [SETUP] Downloading the official Microsoft Visual C++ runtime for clean Windows installs...
curl.exe -fL --retry 3 --output "%INSTALL_DIR%\vc_redist.x64.exe" "https://aka.ms/vs/17/release/vc_redist.x64.exe"
if errorlevel 1 (
  echo [ERROR] Could not download the Microsoft Visual C++ runtime.
  echo Check your internet connection and run build.bat again.
  goto :install_error
)

if not exist "%INSTALL_DIR%\creepclient.exe" (
  echo [ERROR] Build finished but creepclient.exe was not found in dist.
  goto :build_error
)

REM Install Inno Setup only when its compiler is not already available.
where ISCC.exe >nul 2>nul
if errorlevel 1 (
  if not exist "%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe" (
    echo [SETUP] Installing Inno Setup to create a normal Windows installer...
    winget install --id JRSoftware.InnoSetup --exact --source winget --accept-package-agreements --accept-source-agreements
    if errorlevel 1 goto :install_error
  )
)
set "ISCC="
for %%I in ("%ProgramFiles(x86)%\Inno Setup 7\ISCC.exe" "%ProgramFiles%\Inno Setup 7\ISCC.exe" "%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe" "%ProgramFiles%\Inno Setup 6\ISCC.exe") do if exist "%%~I" set "ISCC=%%~I"
if not defined ISCC for /f "delims=" %%I in ('where ISCC.exe 2^>nul') do if not defined ISCC set "ISCC=%%I"
if not defined ISCC (
  echo [ERROR] Inno Setup compiler was not found after installation.
  goto :install_error
)

if not exist "%RELEASE_DIR%" mkdir "%RELEASE_DIR%"
echo.
echo [4/4] Creating the CREEP CLIENT Windows installer...
"%ISCC%" /Qp "%INNO_SCRIPT%"
if errorlevel 1 goto :build_error

if not exist "%RELEASE_DIR%\CREEP_CLIENT_Setup_1.0.0.exe" (
  echo [ERROR] Installer compiler finished but setup EXE was not found.
  goto :build_error
)
echo.
echo  ============================================
echo       CREEP CLIENT INSTALLER CREATED
echo  ============================================
echo.
echo  Installer: %RELEASE_DIR%\CREEP_CLIENT_Setup_1.0.0.exe
echo  After installation, launch CREEP CLIENT from the Start Menu or desktop.
echo  You do NOT need to run build.bat to open the installed launcher.
echo.
start "" "%RELEASE_DIR%\CREEP_CLIENT_Setup_1.0.0.exe"
exit /b 0

:install_error
echo.
echo [ERROR] A dependency could not be installed or downloaded.
echo Check your internet connection, winget, and available disk space.
pause
exit /b 1

:build_error
echo.
echo [ERROR] CREEP CLIENT build failed. Scroll up for the first CMake/compiler error.
echo Build files are retained in: %BUILD_DIR%
pause
exit /b 1
