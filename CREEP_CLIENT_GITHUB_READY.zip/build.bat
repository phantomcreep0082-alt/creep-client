@echo off
setlocal
 title CREEP CLIENT - Cloud Build Instructions
 echo.
 echo  ============================================
 echo          C R E E P   C L I E N T
 echo             CLOUD BUILD MODE
 echo  ============================================
 echo.
 echo  This project now uses GitHub Actions to build the Windows app.
 echo  Do NOT run the old local CMake build again.
 echo.
 echo  Follow PUBLISH_TO_GITHUB.md in this folder.
 echo  GitHub will compile the project on a Windows build machine.
 echo  Then download CREEP_CLIENT_Windows_Installer from Actions ^> Artifacts.
 echo.
 echo  The previous local build script is retained as build-local-legacy.bat.
 echo.
 pause
