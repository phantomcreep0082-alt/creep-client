# CREEP CLIENT — Native Minecraft Launcher

CREEP CLIENT is an independently branded Windows launcher built from the editable Prism Launcher source tree. It keeps the upstream launcher engine and credits the Prism Launcher, PolyMC and MultiMC contributors under the licenses included with this project.

## Current source features

- CREEP CLIENT product name, application ID, executable name, Windows file metadata and installer identity.
- Custom emerald-on-charcoal CREEP icon used for the application and Windows installer.
- Dark charcoal / emerald visual theme and a compact vertical navigation rail.
- Instance workspace and selected-instance actions.
- Home character panel with the account's Minecraft skin, 3D preview when OpenGL is available, auto-rotation, mouse drag rotation, scroll zoom and cape display.
- Minecraft instance creation and launching through the Prism Launcher engine.
- Optional Microsoft account authentication when built with a valid client ID from your own app registration.
- The account manager includes offline-profile options subject to the launcher's existing account-ownership check; this does not bypass Microsoft authentication or Minecraft ownership.
- Built-in Modrinth-compatible mod browsing, install, disable, remove and update controls are available from an instance's Mods page.
- Existing upstream mod-platform integrations, including Modrinth where supported by the upstream source. CurseForge access requires a valid API key and compliance with CurseForge's terms; this build script leaves it disabled by default.

## Build on Windows 10/11 x64

1. Extract this folder to a path with several GB of free disk space.
2. Ensure Windows App Installer (`winget`) is available.
3. Run `build.bat` and allow it to install/download build dependencies.
4. The intended output is `release\CREEP_CLIENT_Setup_1.0.0.exe`.
5. Install it and launch CREEP CLIENT from the Start Menu or optional desktop shortcut.

The script downloads Qt, vcpkg dependencies, Java build tools, the Microsoft Visual C++ runtime and Inno Setup as needed. The first native build is large and may take a while. This source package has not been compiled on this Linux build host; a successful Windows build is not yet verified. If CMake or compilation fails, provide the complete first error from the build log.

## Microsoft account setup

The build asks for a Microsoft application client ID. Use your own public-client/desktop app registration. The client ID is not a password. If left blank, Microsoft sign-in will not be enabled in that build.

## Authentication policy

CREEP CLIENT supports legitimate Microsoft authentication. It does not implement cracked accounts, authentication bypasses, or impersonation of Minecraft accounts. Cached files may be used only where the official game/session rules permit offline use.

## Fast Client executable supplied as a reference

The supplied `FastClient.exe` is a compiled Tauri/Rust application, not editable source code. Its feature names and capabilities were inspected to guide feature comparison, but its compiled code, private assets, authentication routines and proprietary implementation are not copied or embedded into CREEP CLIENT. The two applications use different technology stacks, so their code cannot simply be merged. CREEP CLIENT uses its own editable native source tree.

## Licensing and attribution

This project contains upstream Prism Launcher code and other third-party components. Keep `LICENSE`, `COPYING.md`, component notices and source headers intact. CREEP CLIENT is not endorsed by or affiliated with Prism Launcher or Fast Client.

## Recommended build method: GitHub cloud build

The local batch build has been replaced as the default because repeated Windows CMD/CMake argument issues prevented a reliable local build. Follow `PUBLISH_TO_GITHUB.md` to publish the source to a private GitHub repository. The included `.github/workflows/creep-windows-build.yml` compiles on a hosted Windows x64 runner and uploads `CREEP_CLIENT_Setup.exe` as the `CREEP_CLIENT_Windows_Installer` artifact. The installer is not available until that workflow completes successfully.
