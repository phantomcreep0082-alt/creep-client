# Build CREEP CLIENT without compiling on your PC

This project now includes a GitHub Actions Windows build. GitHub's Windows runner performs the CMake/MSVC build and packages the installer. Your PC only needs to upload/publish the source repository and download the finished artifact.

## One-time setup

1. Sign in to GitHub and create a **private** repository named `creep-client`.
2. Install GitHub Desktop if it is not already installed.
3. In GitHub Desktop, choose **File → Add local repository** and select this `PrismLauncher-develop` folder. If GitHub Desktop says it is not a repository, choose **Create a repository** and select this folder.
4. Commit the files and choose **Publish repository**. Keep it private if you do not want the source public.
5. In the repository on GitHub, open **Actions**. If asked, enable workflows.

## Get the installer

- The workflow named **CREEP CLIENT Windows Build** runs when you push to `main`, or you can open it in Actions and choose **Run workflow**.
- Wait for the run to finish with a green check.
- Open that run, scroll to **Artifacts**, and download `CREEP_CLIENT_Windows_Installer`.
- Extract the downloaded artifact ZIP. It contains `CREEP_CLIENT_Setup.exe`.

## Microsoft sign-in (optional)

If you have your own Microsoft app-registration client ID, add it in repository **Settings → Secrets and variables → Actions → New repository secret** with the name `MSA_CLIENT_ID`. Leave it absent to build without Microsoft sign-in. Never add passwords or client secrets to source files.

## Notes

- This workflow does not implement cracked accounts or bypass Minecraft authentication.
- The first cloud build may take a while because Qt and vcpkg dependencies must be downloaded and compiled.
- A successful workflow is not guaranteed until GitHub completes it. If it fails, share the first red error from the failed step; there is no need to run the local `build.bat`.
