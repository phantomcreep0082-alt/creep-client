// SPDX-License-Identifier: GPL-3.0-only
/*
 *  Prism Launcher - Minecraft Launcher
 *  Copyright (c) 2023 Trial97 <alexandru.tripon97@gmail.com>
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, version 3.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

#include "ListModel.h"
#include <QDir>
#include <QDirListing>
#include <QFileInfo>
#include <QIcon>
#include <QProcessEnvironment>
#include <algorithm>
#include "Application.h"
#include "FileSystem.h"
#include "Json.h"
#include "Result.h"
#include "StringUtils.h"
#include "modplatform/import_ftb/PackHelpers.h"
#include "settings/SettingsObject.h"
#include "ui/widgets/ProjectItem.h"

namespace {
QString getFTBRoot()
{
    QString partialPath = QDir::homePath();
#if defined(Q_OS_MACOS)
    partialPath = FS::PathCombine(partialPath, "Library/Application Support");
#endif
    return FS::PathCombine(partialPath, ".ftba");
}

QString getDynamicPath()
{
    auto settingsPath = FS::PathCombine(getFTBRoot(), "storage", "settings.json");
    if (!QFileInfo::exists(settingsPath)) {
        settingsPath = FS::PathCombine(getFTBRoot(), "bin", "settings.json");
    }
    if (!QFileInfo::exists(settingsPath)) {
        qWarning() << "The ftb app setings doesn't exist.";
        return {};
    }
    auto doc = Json::requireObject(settingsPath).and_then([](const auto& v) { return Json::requireString(v, "instanceLocation"); });
    if (!doc) {
        qCritical() << "Could not read ftb settings file:" << doc.error();
        return {};
    }
    return doc.value();
}
}  // namespace

namespace FTBImportAPP {

ListModel::ListModel(QObject* parent) : QAbstractListModel(parent), m_instancesPath(getDynamicPath()) {}

void ListModel::update()
{
    beginResetModel();
    m_modpacks.clear();

    auto wasPathAdded = [this](const QString& path) {
        return std::ranges::any_of(m_modpacks, [&path](const auto& pack) { return pack.path == path; });
    };

    auto scanPath = [this, wasPathAdded](const QString& path) {
        if (path.isEmpty()) {
            return;
        }
        if (auto instancesInfo = QFileInfo(path); !instancesInfo.exists() || !instancesInfo.isDir()) {
            return;
        }
        for (const auto& entry :
             QDirListing(path, QDirListing::IteratorFlag::DirsOnly | QDirListing::IteratorFlag::ResolveSymlinks |
                                   QDirListing::IteratorFlag::IncludeHidden | QDirListing::IteratorFlag::FollowDirSymlinks)) {
            auto currentPath = entry.absoluteFilePath();
            if (!wasPathAdded(currentPath)) {
                auto modpack = parseDirectory(currentPath);
                if (!modpack) {
                    qDebug() << modpack.error();
                } else if (!modpack->path.isEmpty()) {
                    m_modpacks.append(modpack.value());
                }
            }
        }
    };

    scanPath(APPLICATION->settings()->get("FTBAppInstancesPath").toString());
    scanPath(m_instancesPath);

    endResetModel();
}

QVariant ListModel::data(const QModelIndex& index, int role) const
{
    int pos = index.row();
    if (pos >= m_modpacks.size() || pos < 0 || !index.isValid()) {
        return QVariant();
    }

    auto pack = m_modpacks.at(pos);
    switch (role) {
        case Qt::ToolTipRole:
            return tr("Minecraft %1").arg(pack.mcVersion);
        case Qt::DecorationRole:
            return pack.icon;
        case Qt::UserRole: {
            QVariant v;
            v.setValue(pack);
            return v;
        }
        case Qt::DisplayRole:
            return pack.name;
        case Qt::SizeHintRole:
            return QSize(0, 58);
        // Custom data
        case UserDataTypes::TITLE:
            return pack.name;
        case UserDataTypes::DESCRIPTION:
            return tr("Minecraft %1").arg(pack.mcVersion);
        case UserDataTypes::INSTALLED:
            return false;
        default:
            break;
    }

    return {};
}

FilterModel::FilterModel(QObject* parent) : QSortFilterProxyModel(parent), m_currentSorting(Sorting::ByGameVersion)
{
    m_sortings.insert(tr("Sort by Name"), Sorting::ByName);
    m_sortings.insert(tr("Sort by Game Version"), Sorting::ByGameVersion);
}

bool FilterModel::lessThan(const QModelIndex& left, const QModelIndex& right) const
{
    QVariant leftRaw = sourceModel()->data(left, Qt::UserRole);
    Q_ASSERT(leftRaw.canConvert<Modpack>());
    auto leftPack = leftRaw.value<Modpack>();
    QVariant rightRaw = sourceModel()->data(right, Qt::UserRole);
    Q_ASSERT(rightRaw.canConvert<Modpack>());
    auto rightPack = rightRaw.value<Modpack>();

    if (m_currentSorting == Sorting::ByGameVersion) {
        Version lv(leftPack.mcVersion);
        Version rv(rightPack.mcVersion);
        return lv < rv;
    }
    if (m_currentSorting == Sorting::ByName) {
        return StringUtils::naturalCompare(leftPack.name, rightPack.name, Qt::CaseSensitive) >= 0;
    }

    // UHM, some inavlid value set?!
    qWarning() << "Invalid sorting set!";
    return true;
}

bool FilterModel::filterAcceptsRow([[maybe_unused]] int sourceRow, [[maybe_unused]] const QModelIndex& sourceParent) const
{
    if (m_searchTerm.isEmpty()) {
        return true;
    }
    QModelIndex index = sourceModel()->index(sourceRow, 0, sourceParent);
    QVariant raw = sourceModel()->data(index, Qt::UserRole);
    Q_ASSERT(raw.canConvert<Modpack>());
    auto pack = raw.value<Modpack>();
    return pack.name.contains(m_searchTerm, Qt::CaseInsensitive);
}

void FilterModel::setSearchTerm(const QString& term)
{
    m_searchTerm = term.trimmed();
    invalidate();
}

QMap<QString, FilterModel::Sorting> FilterModel::getAvailableSortings()
{
    return m_sortings;
}

QString FilterModel::translateCurrentSorting()
{
    return m_sortings.key(m_currentSorting);
}

void FilterModel::setSorting(Sorting s)
{
    m_currentSorting = s;
    invalidate();
}

FilterModel::Sorting FilterModel::getCurrentSorting()
{
    return m_currentSorting;
}

void ListModel::setPath(const QString& path)
{
    APPLICATION->settings()->set("FTBAppInstancesPath", path);
    update();
}

QString ListModel::getUserPath()
{
    auto path = APPLICATION->settings()->get("FTBAppInstancesPath").toString();
    if (path.isEmpty()) {
        path = m_instancesPath;
    }
    return path;
}
}  // namespace FTBImportAPP
