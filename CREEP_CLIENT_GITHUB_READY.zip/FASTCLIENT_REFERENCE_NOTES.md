# Fast Client feature reference notes

The supplied FastClient.exe was inspected as a compiled PE32+ x64 Tauri application. Strings in the binary indicate functionality related to Minecraft profile/instance management, Fabric, Forge, NeoForge, Modrinth, CurseForge, bundled Java runtimes, Microsoft/Xbox/Minecraft authentication, skins/capes, modpacks, logs and diagnostics. These are observations from the binary's exposed symbol/string data, not a guarantee that every feature is currently functional or available in every build.

CREEP CLIENT's implementation is based on its own editable Prism Launcher source tree. Do not copy the Fast Client binary, decompile or transplant its proprietary implementation, or reproduce its account-authentication internals. For feature parity, implement equivalent functionality using documented APIs and the existing CREEP CLIENT codebase. Authentication must remain official; cracked-account and authentication-bypass support is intentionally excluded.
